# Installation Instructions

## Important: Extract First!

**npm cannot install directly from zip files.** You must extract the zip file first.

## Installation Steps

### Option 1: Local Installation (Recommended)

1. **Extract the zip file:**
   ```bash
   unzip agent-tool-hub-0.0.1.zip
   ```

2. **Navigate to the extracted directory:**
   ```bash
   cd package
   ```

3. **Install dependencies:**
   ```bash
   npm install
   ```

4. **Install peer dependencies (if needed):**
   ```bash
   npm install @langchain/core @modelcontextprotocol/sdk
   ```

### Option 2: Global Installation

1. **Extract the zip file:**
   ```bash
   unzip agent-tool-hub-0.0.1.zip
   ```

2. **Install globally from the extracted directory:**
   ```bash
   npm install -g ./package
   ```

   Or if you're already in the extracted `package` directory:
   ```bash
   npm install -g .
   ```

### Option 3: Install as Dependency in Another Project

1. **Extract the zip file to a location of your choice**

2. **In your project, install from the extracted path:**
   ```bash
   npm install /path/to/extracted/package
   ```

## Dependencies

This package requires:
- Node.js >= 18.0.0
- Optional peer dependencies:
  - `@langchain/core` (>=0.3.0) - for LangChain tool support
  - `@modelcontextprotocol/sdk` (>=1.0.0) - for MCP tool support

Install peer dependencies as needed:
```bash
npm install @langchain/core @modelcontextprotocol/sdk
```

## Usage

See README.md for usage instructions and examples.

## Available Scripts

After installation, you can use:

- `npm run dump:tools` - Dump all discovered tools to JSON (requires toolhub.yaml in the current directory)

**Note:** Make sure you're in the extracted `package/` directory when running npm scripts.
